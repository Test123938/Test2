describe("Dummy Test Suite", () => {
    it("Should be 10", () => {
        expect(10).toBe(10);
    })
})